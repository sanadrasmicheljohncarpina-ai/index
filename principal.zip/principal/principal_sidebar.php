<?php
// principal_sidebar.php — the ONE sidebar used by every Principal page.
//
// Why this file exists: the Dashboard, Reports and the pages built on
// principal_common.php each used to carry their own sidebar markup and their
// own copy of the sidebar CSS, and the copies had drifted apart (different
// labels, purple vs. gold, different fonts, missing icons). Every page now
// calls render_principal_sidebar() so the markup is identical, and the CSS
// below is scoped to #pbiSidebar. An ID selector out-ranks the class-based
// sidebar rules scattered through the per-page stylesheets and
// includes/principal_light_theme.css, so no page can restyle it.
//
// This file has no dependencies (no session, no DB) so any page can require it.

if (!function_exists('principal_sidebar_assets')) {

    // Fonts + Font Awesome + the sidebar stylesheet. Emitted once per request,
    // so a page that forgot to load them (View Results used to) still gets icons.
    function principal_sidebar_assets(): void {
        static $done = false;
        if ($done) return;
        $done = true;
        ?>
<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@600;700&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
<style id="principal-sidebar-unified">
/* ── Principal sidebar — single source of truth ─────────────────────── */
#pbiSidebar{
  box-sizing:border-box!important;
  width:250px!important;min-width:250px!important;max-width:250px!important;flex:0 0 250px!important;
  position:sticky!important;top:0!important;align-self:flex-start!important;
  height:100vh!important;min-height:100vh!important;overflow-y:auto!important;
  margin:0!important;padding:28px 20px!important;
  display:flex!important;flex-direction:column!important;
  background:#0A192F!important;
  border:0!important;border-right:1px solid #172A45!important;border-radius:0!important;box-shadow:none!important;
  color:#E0E6F0!important;
  font-family:'DM Sans',sans-serif!important;font-size:14px!important;line-height:normal!important;
  text-align:left!important;z-index:20;
}
#pbiSidebar *,#pbiSidebar *::before,#pbiSidebar *::after{box-sizing:border-box;}
#pbiSidebar .sb-profile{display:block!important;text-align:center!important;margin:0 0 26px!important;padding:0!important;background:none!important;border:0!important;}
#pbiSidebar .sb-photo{display:block!important;width:72px!important;height:72px!important;border-radius:50%!important;object-fit:cover!important;border:2.5px solid #d99a2b!important;box-shadow:0 0 18px rgba(217,154,43,.4)!important;margin:0 auto 10px!important;padding:0!important;background:none!important;}
#pbiSidebar .sb-name{margin:0!important;font-family:'DM Sans',sans-serif!important;font-size:15px!important;font-weight:700!important;line-height:1.3!important;letter-spacing:0!important;text-transform:none!important;color:#fff!important;}
#pbiSidebar .sb-role{margin:2px 0 0!important;font-family:'DM Sans',sans-serif!important;font-size:11px!important;font-weight:400!important;line-height:1.3!important;letter-spacing:.6px!important;text-transform:uppercase!important;color:#f0b84d!important;}
#pbiSidebar .sb-scope{margin:4px 0 0!important;font-family:'DM Sans',sans-serif!important;font-size:10px!important;font-weight:400!important;line-height:1.3!important;letter-spacing:0!important;text-transform:none!important;color:#A0B3C6!important;}

#pbiSidebar .sb-nav{display:flex!important;flex-direction:column!important;gap:5px!important;width:100%!important;margin:10px 0 0!important;padding:0!important;background:none!important;border:0!important;}
#pbiSidebar .sb-nav .sb-nav-section-label{display:block!important;width:auto!important;margin:5px 12px 1px!important;padding:0 2px!important;background:none!important;border:0!important;font-family:'DM Sans',sans-serif!important;font-size:11px!important;font-weight:900!important;line-height:1.25!important;letter-spacing:1.6px!important;text-transform:uppercase!important;text-align:center!important;color:#C7D2FE!important;text-shadow:0 1px 8px rgba(129,140,248,.16)!important;}
#pbiSidebar .sb-nav .sb-nav-section-label:first-child{margin-top:0!important;}
#pbiSidebar .sb-nav a{
  display:flex!important;align-items:center!important;gap:10px!important;
  width:100%!important;min-height:42px!important;margin:0!important;padding:5px 14px!important;
  border:0!important;border-radius:8px!important;box-shadow:none!important;transform:none!important;
  background:transparent!important;
  font-family:'DM Sans',sans-serif!important;font-size:14px!important;font-weight:500!important;line-height:1.3!important;letter-spacing:0!important;text-transform:none!important;text-decoration:none!important;
  color:#A0B3C6!important;
  transition:background .2s,color .2s;
}
#pbiSidebar .sb-nav a::before,#pbiSidebar .sb-nav a::after{content:none!important;display:none!important;}
#pbiSidebar .sb-nav a:hover,
#pbiSidebar .sb-nav a.active{background:rgba(217,154,43,.15)!important;color:#fff!important;}
#pbiSidebar .sb-nav a i{display:inline-block!important;flex:0 0 18px!important;width:18px!important;margin:0!important;text-align:center!important;font-size:14px!important;color:#f0b84d!important;}

/* Shared page-title strip: sits on the workspace canvas, not on a white band. */
html body .main.main .page-header.page-header{background:transparent!important;border:0!important;box-shadow:none!important;}

@media (max-width:768px){
  #pbiSidebar{position:static!important;align-self:stretch!important;width:100%!important;min-width:0!important;max-width:none!important;flex:none!important;height:auto!important;min-height:0!important;}
}
@media print{
  #pbiSidebar{display:none!important;}
}
</style>
        <?php
    }
}

if (!function_exists('render_principal_sidebar')) {

    function render_principal_sidebar(string $active, array $me, string $scopeLabel, string $photo_src): void {
        principal_sidebar_assets();

        // Older callers pass 'evaluation'; the canonical key is 'evaluations'.
        if ($active === 'evaluation') $active = 'evaluations';

        $links = [
            'dashboard'   => ['principal_dashboard.php',          'fa-gauge',            'Dashboard'],
            'evaluations' => ['principal_evaluations.php',        'fa-clipboard-list',   'My Evaluation'],
            'tracker'     => ['principal_evaluation_tracker.php', 'fa-satellite-dish',   'Evaluation Tracker'],
            'results'     => ['principal_results.php',            'fa-star-half-stroke', 'View Results'],
            'reports'     => ['principal_reports.php',            'fa-chart-line',       'Evaluation Reports'],
            'settings'    => ['principal_account_settings.php',   'fa-gear',             'Settings'],
        ];
        ?>
    <aside class="sidebar" id="pbiSidebar">
        <div class="sb-profile">
            <img class="sb-photo" src="<?= htmlspecialchars($photo_src) ?>" alt="Profile"/>
            <div class="sb-name"><?= htmlspecialchars($me['full_name'] ?? 'Principal') ?></div>
            <div class="sb-role"><?= htmlspecialchars($me['designation'] ?? 'Principal') ?></div>
            <div class="sb-scope"><?= htmlspecialchars($scopeLabel) ?></div>
        </div>
        <nav class="sb-nav" aria-label="Principal navigation">
            <div class="sb-nav-section-label">MAIN</div>
            <?php foreach (['dashboard', 'evaluations', 'tracker', 'results', 'reports'] as $key): ?>
                <?php [$href, $icon, $label] = $links[$key]; ?>
                <a href="<?= htmlspecialchars($href) ?>" class="<?= $key === $active ? 'active' : '' ?>"<?= $key === $active ? ' aria-current="page"' : '' ?>>
                    <i class="fa-solid <?= htmlspecialchars($icon) ?>"></i> <?= htmlspecialchars($label) ?>
                </a>
            <?php endforeach; ?>

            <div class="sb-nav-section-label">ADMINISTRATION</div>
            <?php [$href, $icon, $label] = $links['settings']; ?>
            <a href="<?= htmlspecialchars($href) ?>" class="<?= $active === 'settings' ? 'active' : '' ?>"<?= $active === 'settings' ? ' aria-current="page"' : '' ?>>
                <i class="fa-solid <?= htmlspecialchars($icon) ?>"></i> <?= htmlspecialchars($label) ?>
            </a>

            <div class="sb-nav-section-label">ACCOUNT</div>
            <a href="../logout.php" class="sb-logout-link">
                <i class="fa-solid fa-right-from-bracket"></i> Log Out
            </a>
        </nav>
    </aside>
        <?php
    }
}
