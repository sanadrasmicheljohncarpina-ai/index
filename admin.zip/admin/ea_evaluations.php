<?php
require_once 'db.php';
if (session_status()===PHP_SESSION_NONE) session_start();
if (empty($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['admin','superadmin'], true)) {header('Location: admin_login.php');exit;}
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
$groups=['Principal'=>[],'Dean'=>[],'Non-Teaching Staff'=>[]];
$r=$mysqli->query("SELECT id,full_name,designation,photo,role FROM users WHERE role IN ('principal','dean') AND is_active=1 AND account_status='approved' ORDER BY full_name");
while($u=$r->fetch_assoc()) $groups[ucfirst($u['role'])][]=$u;
$r=$mysqli->query("SELECT u.id,u.full_name,u.designation,u.photo,u.role,u.secondary_role FROM users u WHERE (u.role='staff' OR u.secondary_role='staff') AND u.is_active=1 AND u.account_status='approved' AND NOT EXISTS (SELECT 1 FROM teaching_assignments ta WHERE ta.user_id=u.id) ORDER BY u.full_name");
while($u=$r->fetch_assoc()) $groups['Non-Teaching Staff'][]=$u;
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>EA Evaluations</title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"><style>
body{margin:0;background:#142238;color:#dbe7f5;font-family:Inter,Arial,sans-serif}.wrap{max-width:1200px;margin:38px auto;padding:0 24px}.back{color:#8ab4f8;text-decoration:none}.head{display:flex;justify-content:space-between;align-items:end;margin:18px 0 28px}.head p{color:#9eb2c9;max-width:760px}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px}.group{background:#233852;border:1px solid #365577;border-radius:16px;overflow:hidden}.gh{padding:18px 20px;border-bottom:1px solid #365577}.gh h2{margin:0;font-size:19px}.count{color:#5eead4;font-size:13px;margin-top:5px}.person{padding:16px 20px;border-bottom:1px solid #304b69;display:flex;align-items:center;justify-content:space-between;gap:12px}.person:last-child{border-bottom:0}.muted{color:#9eb2c9;font-size:13px;margin-top:4px}.btn{background:#14b8a6;color:#06221f;text-decoration:none;border-radius:9px;padding:9px 12px;font-weight:800;font-size:13px}.empty{padding:28px 20px;color:#9eb2c9}@media(max-width:850px){.grid{grid-template-columns:1fr}}
</style>
<!-- Admin text color override: keep standard page text black for readability. -->
<style id="admin-black-text-override">
  body { color:#000 !important; }
  body p, body span, body label, body li, body td, body th,
  body h1, body h2, body h3, body h4, body h5, body h6,
  body .page-title, body .page-header, body .page-header *,
  body .page-sub, body .subtitle, body .description, body .helper,
  body .muted, body .hint, body .section-title, body .section-heading,
  body .card-title, body .card-subtitle, body .form-label,
  body .table-title, body .table-subtitle { color:#000 !important; }
  body a:not(.btn):not(.button):not([class*="btn-"]) { color:#000 !important; }
  body input, body select, body textarea { color:#000 !important; }
  body input::placeholder, body textarea::placeholder { color:#555 !important; }
</style>

<style id="admin-global-black-text">
/* Global admin text treatment: normal interface text is black throughout the admin side.
   Intentional semantic colors on buttons, badges, alerts, icons, and status indicators are preserved. */
body { color:#000 !important; }
body p, body h1, body h2, body h3, body h4, body h5, body h6,
body label, body li, body td, body th, body dt, body dd,
body .page-title, body .page-header, body .page-header p, body .page-sub,
body .subtitle, body .description, body .helper, body .hint, body .muted,
body .section-title, body .section-heading, body .card-title, body .card-subtitle,
body .table-title, body .table-subtitle, body .form-label, body .modal-title, body .modal-sub,
body .empty-state, body .empty-cta, body .field-label, body .stat-label, body .stat-value,
body .back, body .back-btn, body .nav-link, body .sidebar-text, body .content-text { color:#000 !important; }
body a:not(.btn):not(.button):not([class*="btn-"]):not(.badge):not(.status):not(.nav-item) { color:#000 !important; }
body input, body select, body textarea { color:#000 !important; }
body input::placeholder, body textarea::placeholder { color:#555 !important; }
</style>
</head><body><main class="wrap"><a class="back" href="questionnaire.php?view=dashboard&eval_type=ea"><i class="fa-solid fa-arrow-left"></i> Questionnaire</a><div class="head"><div><h1>EA Evaluations</h1><p>The Executive Assistant evaluates the Principal, Dean, and staff members who do not have a teaching assignment. Each evaluation uses the EA-specific questions assigned to that person and role.</p></div></div><div class="grid"><?php foreach($groups as $bucket=>$users): ?><section class="group"><div class="gh"><h2><?=e($bucket)?></h2><div class="count"><?=count($users)?> eligible</div></div><?php if(!$users):?><div class="empty">No eligible personnel.</div><?php else: foreach($users as $u):?><div class="person"><div><strong><?=e($u['full_name'])?></strong><div class="muted"><?=e($u['designation'] ?: $bucket)?></div></div><a class="btn" href="ea_evaluation.php?target_id=<?=$u['id']?>&bucket=<?=urlencode($bucket)?>">Evaluate</a></div><?php endforeach;endif;?></section><?php endforeach;?></div></main></body></html>