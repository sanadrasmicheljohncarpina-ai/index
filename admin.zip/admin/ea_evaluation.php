<?php
// admin/ea_evaluation.php
// EA Evaluation roster. Rebuilt to match the roster -> evaluate pattern
// used everywhere else evaluations happen in this system (see
// dean/dean_evaluation.php + dean/dean_evaluate.php, and
// principal/principal_evaluations.php + principal/principal_evaluate.php):
// a stat/tab/table roster here, a separate server-rendered form on
// ea_evaluate.php. Eligibility is unchanged from before — the EA can only
// evaluate the active Principal, the active Dean, and Staff members who
// have no year-level/teaching assignment.
session_set_cookie_params([
    'lifetime' => 0, 'path' => '/', 'domain' => '',
    'secure' => false, 'httponly' => true, 'samesite' => 'Lax',
]);
session_start();
require_once 'db.php';
require_once dirname(__DIR__) . '/shared/system_settings_service.php';


mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// EA currently maps to the system's privileged/superadmin account.
// Keep executive_assistant here for forward compatibility.
if (!isset($_SESSION['user_id']) ||
    !in_array($_SESSION['role'] ?? '', ['admin','superadmin','executive_assistant'], true)) {
    header('Location: admin_login.php');
    exit;
}

// Apply the schedule before reading evaluation_periods.is_active.
ss_sync_from_database($mysqli);

$ea_id = (int)$_SESSION['user_id'];

// Ensure EA can be stored even on older installations where eval_type was an ENUM.
try {
    $mysqli->query("ALTER TABLE evaluation_tracker MODIFY eval_type VARCHAR(30) NOT NULL DEFAULT 'student'");
} catch (Throwable $ignore) {}

foreach ([
    "ALTER TABLE evaluation_tracker ADD COLUMN evaluator_id INT UNSIGNED NULL",
    "ALTER TABLE evaluation_tracker ADD COLUMN target_user_id INT UNSIGNED NULL",
    "ALTER TABLE evaluation_tracker ADD COLUMN period_id INT UNSIGNED NULL",
    "ALTER TABLE evaluation_tracker ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'submitted'",
] as $ddl) {
    // Ignore duplicate-column errors so the page remains safe on existing databases.
    try { $mysqli->query($ddl); } catch (Throwable $ignore) {}
}

$period = $mysqli->query("
    SELECT id, period_label, is_active
    FROM evaluation_periods
    WHERE is_active=1
    ORDER BY id DESC
    LIMIT 1
")->fetch_assoc();
$period_id = (int)($period['id'] ?? 0);
$is_open = true; // EA Evaluation is always available.

// ── ELIGIBLE TARGETS (unchanged) ──────────────────────────────────────
// Principal + Dean are single-user role targets. Staff = primary Staff
// users with no year-level/teaching assignment. This is
// the exact same eligibility ea_evaluate.php re-checks before accepting
// a submission, so nobody can be evaluated here who isn't allowed.
$heads = ['Principal'=>[], 'Dean'=>[]];
$headStmt = $mysqli->prepare("
    SELECT id, full_name, designation, photo, role
    FROM users
    WHERE role IN ('principal','dean')
      AND is_active=1
      AND account_status='approved'
    ORDER BY full_name
");
$headStmt->execute();
foreach ($headStmt->get_result()->fetch_all(MYSQLI_ASSOC) as $u) {
    $heads[$u['role'] === 'principal' ? 'Principal' : 'Dean'][] = $u;
}
$headStmt->close();

$ntsStmt = $mysqli->prepare("
    SELECT u.id, u.full_name, u.designation, u.photo, u.role
    FROM users u
    WHERE u.role='staff'
      AND u.is_active=1
      AND (u.account_status='approved' OR u.source='admin_nologin')
      AND NOT EXISTS (SELECT 1 FROM teaching_assignments ta WHERE ta.user_id=u.id)
      AND NOT EXISTS (SELECT 1 FROM user_year_levels yl WHERE yl.user_id=u.id)
    ORDER BY u.full_name
");
$ntsStmt->execute();
$nonTeaching = $ntsStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$ntsStmt->close();

$categories = [
    'Principal' => $heads['Principal'],
    'Dean' => $heads['Dean'],
    'Staff' => $nonTeaching,
];
$tabIcons = ['Principal'=>'fa-user-tie','Dean'=>'fa-graduation-cap','Staff'=>'fa-users-gear'];

$selectedType = $_GET['type'] ?? 'Principal';
if (!array_key_exists($selectedType, $categories)) $selectedType = 'Principal';

// Completion state is scoped by eval_type so EA submissions never collide
// with Student, Peer, or School Head evaluations.
$done = [];
if ($period_id) {
    $doneStmt = $mysqli->prepare("
        SELECT target_user_id
        FROM evaluation_tracker
        WHERE evaluator_id=? AND period_id=? AND eval_type='ea' AND status='submitted'
    ");
    $doneStmt->bind_param('ii', $ea_id, $period_id);
    $doneStmt->execute();
    $done = array_flip(array_map('intval', array_column($doneStmt->get_result()->fetch_all(MYSQLI_ASSOC), 'target_user_id')));
    $doneStmt->close();
}

$total = 0; $completed = 0;
foreach ($categories as $group) foreach ($group as $p) { $total++; if (isset($done[(int)$p['id']])) $completed++; }

$justSubmitted = isset($_GET['submitted']);
$mysqli->close();
function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>EA Evaluation — PBI</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{
  --page-bg:#FBFAF5;--card-bg:#FFFFFF;--inner:#FBF9F2;--card-border:#D8C89A;
  --text-dark:#2B2416;--text-dim:#7A6F58;
  --radius:10px;--card-shadow:0 1px 2px rgba(93,72,22,.05),0 4px 12px rgba(93,72,22,.06);
  --accent:#C9A227;--accent-bg:rgba(201,162,39,.08);--accent-border:rgba(201,162,39,.16);--hover:#C9A227;
  --amber:#C77A08;--amber-bg:rgba(217,119,6,.08);--amber-border:rgba(217,119,6,.24);
  --success:#B8860B;--success-bg:rgba(5,150,105,.1);--success-border:rgba(5,150,105,.25);
  --danger:#D6455D;--danger-bg:rgba(220,38,38,.08);--danger-border:rgba(220,38,38,.22);
}
*{box-sizing:border-box} body{margin:0;background:var(--page-bg);color:var(--text-dark);font-family:'Inter',Segoe UI,Arial,sans-serif}
.wrap{max-width:1320px;margin:auto;padding:34px}
.back-link{display:inline-flex;align-items:center;gap:8px;color:var(--text-dim);text-decoration:none;font-size:13px;margin-bottom:20px}
.back-link:hover{color:var(--text-dark)}
.page-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:22px;flex-wrap:wrap;gap:14px;background:var(--card-bg);border:1px solid var(--card-border);border-radius:14px;padding:22px 26px;box-shadow:var(--card-shadow)}
.page-header h1{margin:0;font-family:'Rajdhani',sans-serif;font-size:28px;font-weight:700;color:var(--text-dark)}.page-header p{color:var(--text-dim);margin:6px 0 0;font-size:13px}
.period-badge{background:var(--accent-bg);border:1px solid var(--accent-border);color:var(--accent);padding:8px 16px;border-radius:20px;font-size:12.5px;font-weight:700;display:flex;align-items:center;gap:8px;white-space:nowrap}
.period-badge.closed{background:var(--danger-bg);border-color:var(--danger-border);color:var(--danger)}

.alert{border-radius:10px;padding:13px 16px;font-size:13.5px;margin-bottom:18px;display:flex;align-items:center;gap:8px}
.alert-success{background:var(--success-bg);border:1px solid var(--success-border);color:var(--success)}

.card-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:24px}
.stat-card{background:var(--card-bg);border:1px solid var(--card-border);border-top:4px solid var(--accent);border-radius:14px;padding:18px 20px;box-shadow:var(--card-shadow)}
.stat-card i{color:var(--accent);font-size:18px;margin-bottom:8px;display:block}
.stat-card .num{font-size:26px;font-weight:800;color:var(--text-dark)}
.stat-card .label{font-size:12px;color:var(--text-dim);margin-top:4px}

.eval-tabs{display:flex;gap:4px;background:var(--card-bg);border:1px solid var(--card-border);border-radius:var(--radius);padding:4px;margin-bottom:22px;width:fit-content;flex-wrap:wrap;box-shadow:var(--card-shadow)}
.eval-tab{padding:10px 20px;border-radius:7px;font-size:13.5px;font-weight:700;color:var(--text-dim);text-decoration:none;display:flex;align-items:center;gap:8px}
.eval-tab.active{background:var(--accent);color:#fff}
.eval-tab:not(.active):hover{background:var(--inner);color:var(--text-dark)}
.eval-tab .badge{background:rgba(93,72,22,.13);border-radius:20px;padding:1px 8px;font-size:11px;font-weight:700}
.eval-tab.active .badge{background:rgba(255,255,255,.28)}

.table-wrap{background:var(--card-bg);border:1px solid var(--card-border);border-radius:14px;overflow:hidden;box-shadow:var(--card-shadow)}
table{width:100%;border-collapse:collapse}
thead tr{background:var(--inner)}
thead th{padding:13px 18px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--text-dim);text-align:left;white-space:nowrap;border-bottom:1px solid var(--card-border)}
tbody tr{border-bottom:1px solid var(--card-border)}
tbody tr:last-child{border-bottom:none}
tbody tr:hover{background:var(--page-bg)}
tbody td{padding:14px 18px;font-size:13.5px;vertical-align:middle}
.person-cell{display:flex;align-items:center;gap:11px}
.person-photo{width:38px;height:38px;border-radius:50%;object-fit:cover;background:var(--inner);flex-shrink:0;display:flex;align-items:center;justify-content:center;color:var(--text-dim)}
.person-name{font-weight:700;color:var(--text-dark)}
.muted-cell{color:var(--text-dim);font-size:12.5px}
.status-pill{display:inline-flex;align-items:center;gap:5px;padding:4px 11px;border-radius:20px;font-size:11px;font-weight:800}
.status-pill.done{background:var(--success-bg);color:var(--success)}
.status-pill.pending{background:var(--amber-bg);color:var(--amber)}
.btn-eval{background:var(--accent);border:none;color:#fff;padding:8px 15px;border-radius:8px;font-size:12.5px;font-weight:700;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:6px}
.btn-eval:hover{background:var(--hover)}
.btn-view{background:transparent;border:1px solid var(--card-border);color:var(--text-dim);padding:8px 15px;border-radius:8px;font-size:12.5px;font-weight:700;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:6px;margin-left:6px}
.btn-view:hover{color:var(--text-dark);border-color:#9B8B6A}
.empty-state{text-align:center;padding:56px 20px;color:var(--text-dim)}
.empty-state i{font-size:36px;margin-bottom:14px;display:block;opacity:.3}
@media(max-width:900px){.card-grid{grid-template-columns:1fr}.wrap{padding:20px}}
</style>
    <link rel="stylesheet" href="admin_ui_theme.css">
    <link rel="stylesheet" href="admin_compact_ui.css">
<style id="pbi-feature-scrollbar">

/* PBI FEATURE SCROLLBAR — consistent with the compact page scrollbar */
html, body {
  scrollbar-width: thin !important;
  scrollbar-color: #888 transparent !important;
}
html::-webkit-scrollbar, body::-webkit-scrollbar,
.feature-compact ::-webkit-scrollbar {
  width: 10px !important;
  height: 10px !important;
}
html::-webkit-scrollbar-track, body::-webkit-scrollbar-track,
.feature-compact ::-webkit-scrollbar-track {
  background: transparent !important;
}
html::-webkit-scrollbar-thumb, body::-webkit-scrollbar-thumb,
.feature-compact ::-webkit-scrollbar-thumb {
  background: #888 !important;
  border-radius: 999px !important;
  border: 2px solid transparent !important;
  background-clip: padding-box !important;
}
html::-webkit-scrollbar-thumb:hover, body::-webkit-scrollbar-thumb:hover,
.feature-compact ::-webkit-scrollbar-thumb:hover {
  background: #777 !important;
  background-clip: padding-box !important;
}
html::-webkit-scrollbar-button, body::-webkit-scrollbar-button,
.feature-compact ::-webkit-scrollbar-button {
  display: block !important;
  width: 10px !important;
  height: 10px !important;
  background-color: transparent !important;
}
/* Small native-looking arrow hints on classic scrollbars */
html::-webkit-scrollbar-button:single-button:vertical:decrement,
body::-webkit-scrollbar-button:single-button:vertical:decrement,
.feature-compact ::-webkit-scrollbar-button:single-button:vertical:decrement {
  background:
    linear-gradient(135deg, transparent 50%, #777 50%) 3px 5px/5px 5px no-repeat !important;
}
html::-webkit-scrollbar-button:single-button:vertical:increment,
body::-webkit-scrollbar-button:single-button:vertical:increment,
.feature-compact ::-webkit-scrollbar-button:single-button:vertical:increment {
  background:
    linear-gradient(315deg, transparent 50%, #777 50%) 3px 0/5px 5px no-repeat !important;
}
html::-webkit-scrollbar-button:single-button:horizontal:decrement,
body::-webkit-scrollbar-button:single-button:horizontal:decrement,
.feature-compact ::-webkit-scrollbar-button:single-button:horizontal:decrement {
  background:
    linear-gradient(45deg, transparent 50%, #777 50%) 5px 3px/5px 5px no-repeat !important;
}
html::-webkit-scrollbar-button:single-button:horizontal:increment,
body::-webkit-scrollbar-button:single-button:horizontal:increment,
.feature-compact ::-webkit-scrollbar-button:single-button:horizontal:increment {
  background:
    linear-gradient(225deg, transparent 50%, #777 50%) 0 3px/5px 5px no-repeat !important;
}

</style>

<link rel="stylesheet" href="admin_appearance.css">
<script src="admin_appearance.js"></script>
</head>
<body class="feature-compact">
<main class="wrap">

<a class="back-link" href="admin_dashboard.php" onclick="if(window.parent&&window.parent!==window&&window.parent.showPage){window.parent.showPage('dashboard',window.parent.document.getElementById('link-dashboard'));return false;}"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>

<div class="page-header">
  <div>
    <h1>EA Evaluation</h1>
    <p>Evaluate the active Principal, Dean, and staff members who are not assigned to teach any year level.</p>
  </div>
  <span class="period-badge <?= $is_open ? '' : 'closed' ?>">
    <i class="fa-solid fa-calendar-check"></i>
    <?= e($period['period_label'] ?? 'No active evaluation period') ?> — <?= $is_open ? 'OPEN' : 'CLOSED' ?>
  </span>
</div>

<?php if ($justSubmitted): ?>
<div class="alert alert-success"><i class="fa-solid fa-circle-check"></i> EA evaluation submitted successfully.</div>
<?php endif; ?>

<div class="card-grid">
  <div class="stat-card"><i class="fa-solid fa-list-check"></i><div class="num"><?= $total ?></div><div class="label">Required EA evaluations</div></div>
  <div class="stat-card"><i class="fa-solid fa-circle-check"></i><div class="num"><?= $completed ?></div><div class="label">Completed</div></div>
  <div class="stat-card"><i class="fa-solid fa-hourglass-half"></i><div class="num"><?= max(0,$total-$completed) ?></div><div class="label">Pending</div></div>
</div>

<div class="eval-tabs">
<?php foreach ($categories as $type => $people): ?>
  <a class="eval-tab <?= $selectedType===$type?'active':'' ?>" href="?type=<?= urlencode($type) ?>">
    <i class="fa-solid <?= $tabIcons[$type] ?>"></i> <?= e($type) ?> <span class="badge"><?= count($people) ?></span>
  </a>
<?php endforeach; ?>
</div>

<div class="table-wrap">
<table>
<thead><tr><th>Profile</th><th>Full Name</th><th>Designation</th><th>Evaluation Status</th><th>Actions</th></tr></thead>
<tbody>
<?php if (!$categories[$selectedType]): ?>
<tr><td colspan="5"><div class="empty-state"><i class="fa-solid fa-user-slash"></i><p>No eligible <?= e($selectedType) ?> personnel found.</p></div></td></tr>
<?php else: foreach ($categories[$selectedType] as $p): $pid = (int)$p['id']; $isDone = isset($done[$pid]); ?>
<tr>
  <td><?php if (!empty($p['photo'])): ?><img class="person-photo" src="../image/<?= e($p['photo']) ?>" alt=""><?php else: ?><div class="person-photo"><i class="fa-solid fa-user"></i></div><?php endif; ?></td>
  <td><span class="person-name"><?= e($p['full_name']) ?></span></td>
  <td class="muted-cell"><?= e($p['designation'] ?: $selectedType) ?></td>
  <td>
    <span class="status-pill <?= $isDone ? 'done' : 'pending' ?>">
      <?php if ($isDone): ?><i class="fa-solid fa-check" style="font-size:9px;"></i> Completed
      <?php else: ?><i class="fa-solid fa-hourglass-half" style="font-size:9px;"></i> Pending
      <?php endif; ?>
    </span>
  </td>
  <td>
    <?php if ($isDone): ?>
      <a class="btn-view" href="ea_evaluate.php?type=<?= urlencode($selectedType) ?>&user_id=<?= $pid ?>"><i class="fa-solid fa-eye"></i> View</a>
    <?php else: ?>
      <a class="btn-eval" href="ea_evaluate.php?type=<?= urlencode($selectedType) ?>&user_id=<?= $pid ?>"><i class="fa-solid fa-pen"></i> Evaluate</a>
    <?php endif; ?>
  </td>
</tr>
<?php endforeach; endif; ?>
</tbody>
</table>
</div>

</main>
</body>
</html>
